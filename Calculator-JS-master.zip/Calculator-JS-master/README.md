# Calculator-JS
Simple calculator done with using JavaScript.
